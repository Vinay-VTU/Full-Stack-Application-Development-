package com.vinay.quizengine;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import java.time.LocalDate;

@Controller
public class QuizController {

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @PostMapping("/quiz")
    public String quiz(@RequestParam String name, Model model) {
        model.addAttribute("name", name);
        return "quiz";
    }

    @PostMapping("/result")
    public String result(@RequestParam String name,
                         @RequestParam String q1,
                         @RequestParam String q2,
                         @RequestParam String q3,
                         @RequestParam String q4,
                         @RequestParam String q5,
                         @RequestParam String q6,
                         @RequestParam String q7,
                         @RequestParam String q8,
                         @RequestParam String q9,
                         @RequestParam String q10,
                         @RequestParam String q11,
                         @RequestParam String q12,
                         Model model) {

        int score = 0;

        // General Knowledge
        if(q1.equals("4")) score++;
        if(q2.equals("Paris")) score++;
        if(q3.equals("Shakespeare")) score++;
        if(q4.equals("Mars")) score++;
        if(q5.equals("Pacific")) score++;
        if(q6.equals("New Delhi")) score++;
        if(q7.equals("Tokyo")) score++;
        if(q8.equals("Beijing")) score++;

        // Technical
        if(q9.equals("Cascading Style Sheets")) score++;
        if(q10.equals("JavaScript Object Notation")) score++;
        if(q11.equals("Document Object Model")) score++;
        if(q12.equals("Extensible Markup Language")) score++;

        model.addAttribute("name", name);
        model.addAttribute("score", score);

        return "result";
    }
    @GetMapping("/generate-certificate")
    public void generateCertificate(
            @RequestParam String name,
            @RequestParam int score,
            HttpServletResponse response) {

        try {
            // Set response headers
            response.setContentType("application/pdf");
            response.setHeader("Content-Disposition", "attachment; filename=certificate.pdf");

            // Create PDF document
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, response.getOutputStream());

            document.open();

            // Fonts
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 28, Font.BOLD);
            Font normalFont = new Font(Font.FontFamily.HELVETICA, 18);
            Font boldFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD);

            // Title
            Paragraph title = new Paragraph("Certificate of Achievement", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            document.add(new Paragraph(" "));
            document.add(new Paragraph(" "));

            // Certify text
            Paragraph certify = new Paragraph("This is to certify that", normalFont);
            certify.setAlignment(Element.ALIGN_CENTER);
            document.add(certify);

            document.add(new Paragraph(" "));

            // Name
            Paragraph namePara = new Paragraph(name, boldFont);
            namePara.setAlignment(Element.ALIGN_CENTER);
            document.add(namePara);

            document.add(new Paragraph(" "));

            // Completion text
            Paragraph completion = new Paragraph("has successfully completed the Quiz.", normalFont);
            completion.setAlignment(Element.ALIGN_CENTER);
            document.add(completion);

            document.add(new Paragraph(" "));
            document.add(new Paragraph(" "));

            // Score
            Paragraph scorePara = new Paragraph("Final Score: " + score + " / 12", boldFont);
            scorePara.setAlignment(Element.ALIGN_CENTER);
            document.add(scorePara);

            document.add(new Paragraph(" "));
            document.add(new Paragraph(" "));

      // Date
     Paragraph date = new Paragraph("Date: " + LocalDate.now(), normalFont);
     date.setAlignment(Element.ALIGN_CENTER);
     document.add(date);

            // Close document
            document.close();

        } catch (Exception e) {
            e.printStackTrace(); // Logs the error in console
      }
 }
}
